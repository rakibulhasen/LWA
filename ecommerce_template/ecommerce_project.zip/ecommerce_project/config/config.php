<?php
$dbhost = 'localhost';
$dbname = 'ecommerce_project';
$dbuser = 'root';
$dbpass = '12345678';
try {
    $pdo = new PDO("mysql:host={$dbhost};dbname={$dbname}", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch( PDOException $exception ) {
    echo "Connection error :" . $exception->getMessage();
}

// define('BASE_URL','http://localhost:8080/project/');
// define('ADMIN_URL', BASE_URL.'admin/');
define('SMTP_HOST', 'sandbox.smtp.mailtrap.io');
define('SMTP_PORT', '587');
define('SMTP_USERNAME', '2426032636645e');
define('SMTP_PASSWORD', 'fdf77bfdc4aecd');
define('SMTP_ENCRYPTION', 'tls');
define('SMTP_FROM', 'contact@example.com');