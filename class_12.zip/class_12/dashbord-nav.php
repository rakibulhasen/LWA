<ul class="list-group">
    <li class="list-group-item list-group-action active"><a class="text-white" href="">Order</a></li>
    <li class="list-group-item list-group-action"><a href="<?php echo BASE_URL . 'edit-profile.php' ?>">Profile</a></li>
    <li class="list-group-item list-group-action"><a href="">Status</a></li>
    <li class="list-group-item list-group-action"><a href="<?php echo BASE_URL . 'logout.php' ?>" onclick="return confirm(' Are you sure to logout')">Logout</a></li>
</ul>